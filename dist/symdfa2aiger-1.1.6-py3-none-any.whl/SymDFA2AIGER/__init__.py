from .main import SymDFA2AIGER
